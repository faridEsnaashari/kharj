payments by account and userId

select * from payments as p inner join accounts as a on a.id=p.account_id where a.bank="RESALAT" and user_id=8 order by paid_at desc
