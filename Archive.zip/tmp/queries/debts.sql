select unit, bank, sum(amount), to_user_id,from_user_id, from_name, to_name from (SELECT a.unit, a.bank, ad.amount, ad.to_user_id,ad.from_user_id, tu.name as to_name, u.name as from_name FROM account_debts as ad inner join users as u on u.id=ad.from_user_id inner join users as tu on tu.id=ad.to_user_id inner join payments as p on p.id=ad.payment_id inner join accounts as a on a.id=p.account_id where ad.from_user_id=8 or ad.to_user_id=8 order by ad.created_at desc) as t group by bank , unit, to_user_id, from_user_id;


sum of debts by unit

select unit, sum(amount), to_user_id,from_user_id, from_name, to_name from (SELECT a.unit, a.bank, ad.amount, ad.to_user_id,ad.from_user_id, tu.name as to_name, u.name as from_name FROM account_debts as ad inner join users as u on u.id=ad.from_user_id inner join users as tu on tu.id=ad.to_user_id inner join payments as p on p.id=ad.payment_id inner join accounts as a on a.id=p.account_id where ad.from_user_id=8 or ad.to_user_id=8 order by ad.created_at desc) as t group by  unit, to_user_id, from_user_id;


final sum by unit
 
SELECT
    d1.unit,
    d1.from_user_id,
    d1.from_name,
    d1.to_user_id,
    d1.to_name,
    d1.amount AS debt_amount,
    COALESCE(d2.amount, 0) AS reverse_debt_amount,
    d1.amount - COALESCE(d2.amount, 0) AS net_amount
FROM (
    select
        unit,
        sum(amount) as amount,
        to_user_id,
        from_user_id,
        from_name,
        to_name
    from (
        SELECT
            a.unit,
            ad.amount,
            ad.to_user_id,
            ad.from_user_id,
            tu.name as to_name,
            u.name as from_name
        FROM account_debts ad
        INNER JOIN users u
            ON u.id = ad.from_user_id
        INNER JOIN users tu
            ON tu.id = ad.to_user_id
        INNER JOIN payments p
            ON p.id = ad.payment_id
        INNER JOIN accounts a
            ON a.id = p.account_id
        WHERE ad.from_user_id = 8
           OR ad.to_user_id = 8
    ) t
    GROUP BY
        unit,
        to_user_id,
        from_user_id,
        from_name,
        to_name
) d1
LEFT JOIN (
    select
        unit,
        sum(amount) as amount,
        to_user_id,
        from_user_id
    from (
        SELECT
            a.unit,
            ad.amount,
            ad.to_user_id,
            ad.from_user_id
        FROM account_debts ad
        INNER JOIN payments p
            ON p.id = ad.payment_id
        INNER JOIN accounts a
            ON a.id = p.account_id
    ) t
    GROUP BY unit, to_user_id, from_user_id
) d2
    ON d1.unit = d2.unit
   AND d1.from_user_id = d2.to_user_id
   AND d1.to_user_id = d2.from_user_id
where d1.from_user_id=8;
