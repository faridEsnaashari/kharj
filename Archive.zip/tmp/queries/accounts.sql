
SELECT sum(ballance) FROM `accounts` where user_id=8 and bank="RESALAT";
