export enum IncomeCategory {
  HOGHOOGH = 'HOGHOOGH',
  MOSAEDEH = 'MOSAEDEH',
  BEDEHI = 'BEDEHI',
  LOAN = 'LOAN',
  EXCHANGE = 'EXCHANGE',
  SNAPP = 'SNAPP',
  MS = 'MS',
}
