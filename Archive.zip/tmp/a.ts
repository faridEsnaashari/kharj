import { NestFactory } from '@nestjs/core';
import { AppModule } from 'src/app.module';
import {xlsxToJson} from 'src/file/logics/xlsx.logic';

async function bootstrap() {
  const appContext = await NestFactory.createApplicationContext(AppModule);

  const js=await xlsxToJson("./")

  await appContext.close();
}

bootstrap();
